#!/usr/bin/env python3
"""
Pipeline Dashboard — central monitoring and control panel for the weather
pipeline.  Reads status JSONs from the shared /status volume, serves the
latest screenshot and processed images, and issues Docker commands (stop,
start, rebuild) via the mounted Docker socket.

Endpoints
─────────
GET  /                          → dashboard HTML
GET  /api/status                → aggregated status of all services
GET  /api/screenshots/latest    → latest raw screenshot PNG
GET  /api/processed/latest      → latest processed JSON filename + metadata
POST /api/services/<name>/stop  → docker compose stop
POST /api/services/<name>/start → docker compose start
POST /api/services/<name>/update→ docker compose up -d --build (rebuild)
GET  /api/services/<name>/logs  → last 80 lines of container logs
"""

import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock

from flask import Flask, jsonify, request, send_file, send_from_directory

# ── Configuration ────────────────────────────────────────────────────────────

STATUS_DIR = Path(os.getenv("STATUS_DIR", "/status"))
SCREENSHOTS_DIR = Path(os.getenv("SCREENSHOTS_DIR", "/screenshots"))
PROCESSED_DIR = Path(os.getenv("PROCESSED_DIR", "/processed"))

# Each service: container_name → docker-compose project directory (on host)
SERVICES = {
    "screenshot-service": {
        "label": "Screenshot Service",
        "compose_dir": os.getenv("SS_COMPOSE_DIR", "/projects/screenshot-service"),
        "status_file": "screenshot_status.json",
        "container": "screenshot-service",
    },
    "radar-processor": {
        "label": "Radar Processor",
        "compose_dir": os.getenv("RP_COMPOSE_DIR", "/projects/radar-processor"),
        "status_file": "processor_status.json",
        "container": "radar-processor",
    },
    "weather-reporter": {
        "label": "Weather Reporter",
        "compose_dir": os.getenv("WR_COMPOSE_DIR", "/projects/weather-reporter"),
        "status_file": "weather_status.json",
        "container": "weather-reporter",
    },
}

# ── Helpers ──────────────────────────────────────────────────────────────────

_cmd_lock = Lock()  # serialise Docker commands


def _read_status(filename: str) -> dict | None:
    p = STATUS_DIR / filename
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except Exception:
        return None


def _latest_file(directory: Path, glob: str) -> Path | None:
    """Return the most-recently-modified file matching *glob*."""
    files = sorted(directory.glob(glob), key=lambda f: f.stat().st_mtime, reverse=True)
    return files[0] if files else None


def _folder_stats(directory: Path) -> dict:
    if not directory.exists():
        return {"count": 0, "size_mb": 0}
    files = [f for f in directory.iterdir() if f.is_file()]
    return {
        "count": len(files),
        "size_mb": round(sum(f.stat().st_size for f in files) / 1_048_576, 2),
    }


def _run_compose(compose_dir: str, *args, timeout: int = 300) -> dict:
    """Run a docker compose command in the given project directory."""
    # Prefer `docker compose` (v2 plugin); fall back to `docker-compose`.
    for cmd_base in (["docker", "compose"], ["docker-compose"]):
        try:
            cmd = [*cmd_base, *args]
            result = subprocess.run(
                cmd,
                cwd=compose_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            return {
                "ok": result.returncode == 0,
                "stdout": result.stdout[-2000:],  # cap output
                "stderr": result.stderr[-2000:],
                "code": result.returncode,
            }
        except FileNotFoundError:
            continue
        except subprocess.TimeoutExpired:
            return {"ok": False, "stdout": "", "stderr": "Command timed out", "code": -1}
    return {"ok": False, "stdout": "", "stderr": "docker compose not found", "code": -1}


def _container_logs(container_name: str, lines: int = 80) -> str:
    try:
        r = subprocess.run(
            ["docker", "logs", "--tail", str(lines), container_name],
            capture_output=True, text=True, timeout=10,
        )
        return r.stdout + r.stderr
    except Exception as e:
        return f"Error fetching logs: {e}"


def _container_state(container_name: str) -> str:
    """Return running / exited / not_found."""
    try:
        r = subprocess.run(
            ["docker", "inspect", "-f", "{{.State.Status}}", container_name],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            return r.stdout.strip()
        return "not_found"
    except Exception:
        return "unknown"


# ── Flask app ────────────────────────────────────────────────────────────────

app = Flask(__name__, static_folder=None)


@app.route("/")
def index():
    return send_from_directory("/app/static", "index.html")


@app.route("/static/<path:path>")
def static_files(path):
    return send_from_directory("/app/static", path)


# ── Aggregated status ────────────────────────────────────────────────────────

@app.route("/api/status")
def api_status():
    services = {}
    for key, svc in SERVICES.items():
        status_data = _read_status(svc["status_file"])
        docker_state = _container_state(svc["container"])
        services[key] = {
            "label": svc["label"],
            "docker_state": docker_state,
            "status_data": status_data,
        }

    # Latest screenshot info
    latest_ss = _latest_file(SCREENSHOTS_DIR, "radar_*.png")
    ss_info = None
    if latest_ss:
        ss_info = {
            "filename": latest_ss.name,
            "modified": latest_ss.stat().st_mtime,
            "size_bytes": latest_ss.stat().st_size,
        }

    # Latest processed
    latest_pr = _latest_file(PROCESSED_DIR, "radar_*.json")
    pr_info = None
    if latest_pr:
        pr_info = {
            "filename": latest_pr.name,
            "modified": latest_pr.stat().st_mtime,
            "size_bytes": latest_pr.stat().st_size,
        }

    return jsonify({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "services": services,
        "latest_screenshot": ss_info,
        "latest_processed": pr_info,
        "folders": {
            "screenshots": _folder_stats(SCREENSHOTS_DIR),
            "processed": _folder_stats(PROCESSED_DIR),
        },
    })


# ── Image endpoints ──────────────────────────────────────────────────────────

@app.route("/api/screenshots/latest")
def latest_screenshot():
    f = _latest_file(SCREENSHOTS_DIR, "radar_*.png")
    if not f:
        return jsonify({"error": "No screenshots found"}), 404
    return send_file(f, mimetype="image/png")


@app.route("/api/processed/latest")
def latest_processed():
    f = _latest_file(PROCESSED_DIR, "radar_*.json")
    if not f:
        return jsonify({"error": "No processed files found"}), 404
    # Return just metadata, not the full multi-MB data array
    try:
        data = json.loads(f.read_text())
        meta = data.get("metadata", {})
        meta["_filename"] = f.name
        meta["_size_bytes"] = f.stat().st_size
        return jsonify(meta)
    except Exception:
        return jsonify({"error": "Failed to read file"}), 500


# ── Service control ──────────────────────────────────────────────────────────

@app.route("/api/services/<name>/stop", methods=["POST"])
def svc_stop(name):
    if name not in SERVICES:
        return jsonify({"error": "Unknown service"}), 404
    with _cmd_lock:
        result = _run_compose(SERVICES[name]["compose_dir"], "stop")
    return jsonify(result)


@app.route("/api/services/<name>/start", methods=["POST"])
def svc_start(name):
    if name not in SERVICES:
        return jsonify({"error": "Unknown service"}), 404
    with _cmd_lock:
        result = _run_compose(SERVICES[name]["compose_dir"], "start")
    return jsonify(result)


@app.route("/api/services/<name>/update", methods=["POST"])
def svc_update(name):
    if name not in SERVICES:
        return jsonify({"error": "Unknown service"}), 404
    with _cmd_lock:
        result = _run_compose(
            SERVICES[name]["compose_dir"],
            "up", "-d", "--build",
            timeout=600,  # builds can be slow
        )
    return jsonify(result)


@app.route("/api/services/<name>/logs")
def svc_logs(name):
    if name not in SERVICES:
        return jsonify({"error": "Unknown service"}), 404
    lines = request.args.get("lines", 80, type=int)
    text = _container_logs(SERVICES[name]["container"], lines)
    return jsonify({"logs": text})


# ── Health ───────────────────────────────────────────────────────────────────

@app.route("/health")
def health():
    return jsonify({"status": "healthy"})


# ── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.getenv("PORT", "9007"))
    print(f"Dashboard starting on :{port}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
